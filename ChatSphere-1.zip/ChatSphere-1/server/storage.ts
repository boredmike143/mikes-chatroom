import { type User, type InsertUser, type Message, type InsertMessage } from "@shared/schema";
import { randomUUID } from "crypto";

export interface IStorage {
  getUser(id: string): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;
  
  // Message operations
  getMessages(): Promise<Message[]>;
  createMessage(message: InsertMessage): Promise<Message>;
  
  // Session user operations
  getUserSession(sessionId: string): Promise<string | undefined>;
  setUserSession(sessionId: string, username: string): Promise<void>;
  updateSessionUsername(sessionId: string, newUsername: string): Promise<void>;
  
  // Online user operations
  getOnlineUsers(): Promise<string[]>;
  updateUserActivity(username: string): Promise<void>;
  removeInactiveUsers(): Promise<void>;
}

export class MemStorage implements IStorage {
  private users: Map<string, User>;
  private messages: Message[];
  private sessions: Map<string, string>; // sessionId -> username
  private onlineUsers: Map<string, Date>; // username -> last activity timestamp

  constructor() {
    this.users = new Map();
    this.messages = [];
    this.sessions = new Map();
    this.onlineUsers = new Map();
    
    // Clean up inactive users every 30 seconds
    setInterval(() => {
      this.removeInactiveUsers();
    }, 30000);
  }

  async getUser(id: string): Promise<User | undefined> {
    return this.users.get(id);
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    return Array.from(this.users.values()).find(
      (user) => user.username === username,
    );
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const id = randomUUID();
    const user: User = { ...insertUser, id };
    this.users.set(id, user);
    return user;
  }

  async getMessages(): Promise<Message[]> {
    return [...this.messages].sort((a, b) => new Date(a.timestamp).getTime() - new Date(b.timestamp).getTime());
  }

  async createMessage(insertMessage: InsertMessage): Promise<Message> {
    const id = randomUUID();
    const message: Message = {
      id,
      content: insertMessage.content,
      username: insertMessage.username,
      timestamp: new Date(),
    };
    this.messages.push(message);
    return message;
  }

  async getUserSession(sessionId: string): Promise<string | undefined> {
    return this.sessions.get(sessionId);
  }

  async setUserSession(sessionId: string, username: string): Promise<void> {
    this.sessions.set(sessionId, username);
  }

  async updateSessionUsername(sessionId: string, newUsername: string): Promise<void> {
    // Get the old username before updating
    const oldUsername = this.sessions.get(sessionId);
    
    // Update the session with new username
    this.sessions.set(sessionId, newUsername);
    
    // Remove old username from online users if it exists
    if (oldUsername) {
      this.onlineUsers.delete(oldUsername);
    }
    
    // Add new username to online users
    this.onlineUsers.set(newUsername, new Date());
  }

  async getOnlineUsers(): Promise<string[]> {
    await this.removeInactiveUsers();
    return Array.from(this.onlineUsers.keys()).sort();
  }

  async updateUserActivity(username: string): Promise<void> {
    this.onlineUsers.set(username, new Date());
  }

  async removeInactiveUsers(): Promise<void> {
    const now = new Date();
    const inactiveThreshold = 2 * 60 * 1000; // 2 minutes
    
    for (const [username, lastActivity] of this.onlineUsers.entries()) {
      if (now.getTime() - lastActivity.getTime() > inactiveThreshold) {
        this.onlineUsers.delete(username);
      }
    }
  }
}

export const storage = new MemStorage();
