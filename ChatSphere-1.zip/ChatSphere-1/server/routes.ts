import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { insertMessageSchema, updateUsernameSchema } from "@shared/schema";
import { randomUUID } from "crypto";
import session from "express-session";

export async function registerRoutes(app: Express): Promise<Server> {
  // Session middleware
  app.use(session({
    secret: process.env.SESSION_SECRET || 'fallback-secret-key-change-in-production',
    resave: false,
    saveUninitialized: true,
    cookie: { 
      secure: false, // Set to true in production with HTTPS
      maxAge: 24 * 60 * 60 * 1000 // 24 hours
    }
  }));

  // Get all messages
  app.get("/api/messages", async (req, res) => {
    try {
      const messages = await storage.getMessages();
      res.json(messages);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch messages" });
    }
  });

  // Send a new message
  app.post("/api/messages", async (req, res) => {
    try {
      const sessionId = req.session.id;
      let username = await storage.getUserSession(sessionId);
      
      // If no username in session, generate a random one
      if (!username) {
        username = `User${Math.floor(Math.random() * 10000)}`;
        await storage.setUserSession(sessionId, username);
      }

      // Track user activity
      await storage.updateUserActivity(username);

      const messageData = insertMessageSchema.parse({
        content: req.body.content,
        username: username
      });

      const message = await storage.createMessage(messageData);
      res.json(message);
    } catch (error) {
      if (error instanceof Error) {
        res.status(400).json({ message: error.message });
      } else {
        res.status(500).json({ message: "Failed to create message" });
      }
    }
  });

  // Get current user info
  app.get("/api/user", async (req, res) => {
    try {
      const sessionId = req.session.id;
      let username = await storage.getUserSession(sessionId);
      
      // If no username in session, generate a random one
      if (!username) {
        username = `User${Math.floor(Math.random() * 10000)}`;
        await storage.setUserSession(sessionId, username);
      }

      // Track user activity
      await storage.updateUserActivity(username);

      res.json({ username });
    } catch (error) {
      res.status(500).json({ message: "Failed to get user info" });
    }
  });

  // Update username
  app.put("/api/user/username", async (req, res) => {
    try {
      const sessionId = req.session.id;
      const { newUsername } = updateUsernameSchema.parse(req.body);
      
      await storage.updateSessionUsername(sessionId, newUsername);
      // Track user activity with new username
      await storage.updateUserActivity(newUsername);
      
      res.json({ username: newUsername });
    } catch (error) {
      if (error instanceof Error) {
        res.status(400).json({ message: error.message });
      } else {
        res.status(500).json({ message: "Failed to update username" });
      }
    }
  });

  // Get online user count
  app.get("/api/stats", async (req, res) => {
    try {
      const onlineUsers = await storage.getOnlineUsers();
      res.json({ onlineCount: onlineUsers.length });
    } catch (error) {
      res.status(500).json({ message: "Failed to get stats" });
    }
  });

  // Get online users list
  app.get("/api/users/online", async (req, res) => {
    try {
      const onlineUsers = await storage.getOnlineUsers();
      res.json({ users: onlineUsers });
    } catch (error) {
      res.status(500).json({ message: "Failed to get online users" });
    }
  });

  const httpServer = createServer(app);
  return httpServer;
}
