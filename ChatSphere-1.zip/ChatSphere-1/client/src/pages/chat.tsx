import { useEffect } from "react";
import { useQuery } from "@tanstack/react-query";
import { queryClient } from "@/lib/queryClient";
import { ChatHeader } from "@/components/chat-header";
import { MessageFeed } from "@/components/message-feed";
import { MessageInput } from "@/components/message-input";
import { UsernameModal } from "@/components/username-modal";
import { OnlineUsers } from "@/components/online-users";
import { useState } from "react";

interface Message {
  id: string;
  content: string;
  username: string;
  timestamp: string;
}

interface User {
  username: string;
}

interface Stats {
  onlineCount: number;
}

export default function Chat() {
  const [isUsernameModalOpen, setIsUsernameModalOpen] = useState(false);

  // Fetch messages
  const { data: messages = [], isLoading: messagesLoading } = useQuery<Message[]>({
    queryKey: ["/api/messages"],
    refetchInterval: 3000, // Poll every 3 seconds
  });

  // Fetch user info
  const { data: user } = useQuery<User>({
    queryKey: ["/api/user"],
  });

  // Fetch stats
  const { data: stats } = useQuery<Stats>({
    queryKey: ["/api/stats"],
    refetchInterval: 10000, // Poll every 10 seconds
  });

  return (
    <div className="bg-background text-foreground min-h-screen flex flex-col" data-testid="chat-container">
      <ChatHeader 
        onlineCount={stats?.onlineCount ?? 0}
        currentUser={user?.username ?? ""}
        onOpenSettings={() => setIsUsernameModalOpen(true)}
      />
      
      <div className="flex flex-1 overflow-hidden">
        <div className="flex flex-col flex-1">
          <MessageFeed 
            messages={messages}
            currentUsername={user?.username ?? ""}
            isLoading={messagesLoading}
          />
          
          <MessageInput />
        </div>
        
        <OnlineUsers currentUsername={user?.username ?? ""} />
      </div>
      
      <UsernameModal 
        isOpen={isUsernameModalOpen}
        onClose={() => setIsUsernameModalOpen(false)}
        currentUsername={user?.username ?? ""}
      />
    </div>
  );
}
