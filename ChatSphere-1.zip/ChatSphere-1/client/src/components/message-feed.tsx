import { useEffect, useRef } from "react";
import { format } from "date-fns";

interface Message {
  id: string;
  content: string;
  username: string;
  timestamp: string;
}

interface MessageFeedProps {
  messages: Message[];
  currentUsername: string;
  isLoading: boolean;
}

export function MessageFeed({ messages, currentUsername, isLoading }: MessageFeedProps) {
  const messagesEndRef = useRef<HTMLDivElement>(null);

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" });
  };

  useEffect(() => {
    scrollToBottom();
  }, [messages]);

  const getUserInitials = (username: string) => {
    return username.slice(0, 2).toUpperCase();
  };

  const formatTimestamp = (timestamp: string) => {
    return format(new Date(timestamp), "h:mm a");
  };

  const getAvatarColor = (username: string) => {
    const colors = [
      "bg-primary",
      "bg-secondary", 
      "bg-accent",
      "bg-muted",
      "bg-chart-1",
      "bg-chart-2",
      "bg-chart-3",
      "bg-chart-4",
      "bg-chart-5"
    ];
    
    let hash = 0;
    for (let i = 0; i < username.length; i++) {
      hash = username.charCodeAt(i) + ((hash << 5) - hash);
    }
    return colors[Math.abs(hash) % colors.length];
  };

  if (isLoading && messages.length === 0) {
    return (
      <main className="flex-1 overflow-hidden flex flex-col">
        <div className="flex-1 overflow-y-auto p-4 space-y-4" data-testid="messages-container">
          <div className="flex items-center justify-center h-32">
            <div className="text-muted-foreground">Loading messages...</div>
          </div>
        </div>
      </main>
    );
  }

  return (
    <main className="flex-1 overflow-hidden flex flex-col">
      <div className="flex-1 overflow-y-auto p-4 space-y-4" data-testid="messages-container">
        {messages.length === 0 ? (
          <div className="flex items-center justify-center h-32">
            <div className="text-muted-foreground">No messages yet. Be the first to say hello!</div>
          </div>
        ) : (
          messages.map((message) => {
            const isCurrentUser = message.username === currentUsername;
            const avatarColor = getAvatarColor(message.username);
            
            return (
              <div key={message.id} className="message-bubble" data-testid={`message-${message.id}`}>
                <div className="flex items-start space-x-3 group">
                  <div className={`w-8 h-8 ${avatarColor} rounded-full flex items-center justify-center flex-shrink-0`}>
                    <span className="text-xs font-medium text-white">
                      {getUserInitials(message.username)}
                    </span>
                  </div>
                  <div className="flex-1 min-w-0">
                    <div className="flex items-baseline space-x-2 mb-1">
                      <span className="text-sm font-medium text-foreground" data-testid={`text-username-${message.id}`}>
                        {message.username}
                      </span>
                      <span className="text-xs text-muted-foreground" data-testid={`text-timestamp-${message.id}`}>
                        {formatTimestamp(message.timestamp)}
                      </span>
                      {isCurrentUser && (
                        <span className="text-xs text-primary font-medium">You</span>
                      )}
                    </div>
                    <p className="text-foreground leading-relaxed" data-testid={`text-content-${message.id}`}>
                      {message.content}
                    </p>
                  </div>
                </div>
              </div>
            );
          })
        )}
        <div ref={messagesEndRef} />
      </div>
    </main>
  );
}
