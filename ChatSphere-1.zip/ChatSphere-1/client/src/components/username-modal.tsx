import { useState, useEffect } from "react";
import { useMutation } from "@tanstack/react-query";
import { X } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { queryClient, apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";

interface UsernameModalProps {
  isOpen: boolean;
  onClose: () => void;
  currentUsername: string;
}

export function UsernameModal({ isOpen, onClose, currentUsername }: UsernameModalProps) {
  const [newUsername, setNewUsername] = useState("");
  const { toast } = useToast();

  useEffect(() => {
    if (isOpen) {
      setNewUsername(currentUsername);
    }
  }, [isOpen, currentUsername]);

  const updateUsername = useMutation({
    mutationFn: async (username: string) => {
      return apiRequest("PUT", "/api/user/username", { newUsername: username });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/user"] });
      queryClient.invalidateQueries({ queryKey: ["/api/messages"] });
      toast({
        title: "Success",
        description: "Username updated successfully!",
      });
      onClose();
    },
    onError: (error) => {
      toast({
        title: "Error",
        description: "Failed to update username. Please try again.",
        variant: "destructive",
      });
    },
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const trimmedUsername = newUsername.trim();
    
    if (!trimmedUsername || trimmedUsername.length < 2 || trimmedUsername.length > 30) {
      return;
    }
    
    if (!/^[a-zA-Z0-9]+$/.test(trimmedUsername)) {
      toast({
        title: "Invalid Username",
        description: "Username must contain only letters and numbers.",
        variant: "destructive",
      });
      return;
    }
    
    updateUsername.mutate(trimmedUsername);
  };

  const isValid = newUsername.trim().length >= 2 && 
                  newUsername.trim().length <= 30 && 
                  /^[a-zA-Z0-9]+$/.test(newUsername.trim());

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="max-w-md" data-testid="modal-username">
        <DialogHeader>
          <DialogTitle data-testid="text-modal-title">Change Username</DialogTitle>
        </DialogHeader>
        
        <form onSubmit={handleSubmit} className="space-y-4">
          <div className="space-y-2">
            <Label htmlFor="new-username" data-testid="label-username">
              New Username
            </Label>
            <Input
              id="new-username"
              type="text"
              placeholder="Enter your new username"
              maxLength={30}
              value={newUsername}
              onChange={(e) => setNewUsername(e.target.value)}
              data-testid="input-new-username"
            />
            <p className="text-xs text-muted-foreground" data-testid="text-username-help">
              Must be 2-30 characters, letters and numbers only
            </p>
          </div>
          
          <div className="flex items-center justify-end space-x-3">
            <Button 
              type="button"
              variant="outline"
              onClick={onClose}
              data-testid="button-cancel">
              Cancel
            </Button>
            <Button 
              type="submit"
              disabled={!isValid || updateUsername.isPending}
              data-testid="button-save">
              {updateUsername.isPending ? "Saving..." : "Save Changes"}
            </Button>
          </div>
        </form>
      </DialogContent>
    </Dialog>
  );
}
