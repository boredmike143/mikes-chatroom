import { useQuery } from "@tanstack/react-query";
import { Users } from "lucide-react";

interface OnlineUsersResponse {
  users: string[];
}

interface OnlineUsersProps {
  currentUsername: string;
}

export function OnlineUsers({ currentUsername }: OnlineUsersProps) {
  const { data: onlineUsersData } = useQuery<OnlineUsersResponse>({
    queryKey: ["/api/users/online"],
    refetchInterval: 10000, // Poll every 10 seconds
  });

  const onlineUsers = onlineUsersData?.users || [];

  const getUserInitials = (username: string) => {
    return username.slice(0, 2).toUpperCase();
  };

  const getAvatarColor = (username: string) => {
    const colors = [
      "bg-primary",
      "bg-secondary", 
      "bg-accent",
      "bg-muted",
      "bg-chart-1",
      "bg-chart-2",
      "bg-chart-3",
      "bg-chart-4",
      "bg-chart-5"
    ];
    
    let hash = 0;
    for (let i = 0; i < username.length; i++) {
      hash = username.charCodeAt(i) + ((hash << 5) - hash);
    }
    return colors[Math.abs(hash) % colors.length];
  };

  return (
    <aside className="w-64 bg-card border-l border-border flex flex-col" data-testid="sidebar-online-users">
      <div className="p-4 border-b border-border">
        <div className="flex items-center space-x-2">
          <Users size={16} className="text-muted-foreground" />
          <h2 className="text-sm font-semibold text-foreground" data-testid="text-online-users-title">
            Online Users
          </h2>
          <span className="text-xs text-muted-foreground bg-muted px-2 py-1 rounded-full" data-testid="text-online-count">
            {onlineUsers.length}
          </span>
        </div>
      </div>
      
      <div className="flex-1 overflow-y-auto p-4 space-y-2" data-testid="online-users-list">
        {onlineUsers.length === 0 ? (
          <div className="text-center text-muted-foreground text-sm py-8">
            No users online
          </div>
        ) : (
          onlineUsers.map((username) => {
            const isCurrentUser = username === currentUsername;
            const avatarColor = getAvatarColor(username);
            
            return (
              <div 
                key={username} 
                className="flex items-center space-x-3 p-2 rounded-lg hover:bg-accent/50 transition-colors"
                data-testid={`user-${username}`}
              >
                <div className={`w-8 h-8 ${avatarColor} rounded-full flex items-center justify-center flex-shrink-0 relative`}>
                  <span className="text-xs font-medium text-white">
                    {getUserInitials(username)}
                  </span>
                  <div className="absolute -bottom-1 -right-1 w-3 h-3 bg-green-500 border-2 border-card rounded-full"></div>
                </div>
                <div className="flex-1 min-w-0">
                  <div className="flex items-center space-x-2">
                    <span className="text-sm font-medium text-foreground truncate" data-testid={`text-username-${username}`}>
                      {username}
                    </span>
                    {isCurrentUser && (
                      <span className="text-xs text-primary font-medium">(You)</span>
                    )}
                  </div>
                  <span className="text-xs text-green-500">Online</span>
                </div>
              </div>
            );
          })
        )}
      </div>
    </aside>
  );
}