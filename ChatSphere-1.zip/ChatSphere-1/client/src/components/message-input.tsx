import { useState } from "react";
import { useMutation } from "@tanstack/react-query";
import { Send } from "lucide-react";
import { queryClient, apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";

export function MessageInput() {
  const [message, setMessage] = useState("");
  const { toast } = useToast();

  const getWordCount = (text: string) => {
    return text.trim().split(/\s+/).filter(word => word.length > 0).length;
  };

  const sendMessage = useMutation({
    mutationFn: async (content: string) => {
      return apiRequest("POST", "/api/messages", { content });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/messages"] });
      setMessage("");
    },
    onError: (error) => {
      toast({
        title: "Error",
        description: "Failed to send message. Please try again.",
        variant: "destructive",
      });
    },
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const trimmedMessage = message.trim();
    const wordCount = getWordCount(trimmedMessage);
    
    if (!trimmedMessage || wordCount > 1500) {
      return;
    }
    
    sendMessage.mutate(trimmedMessage);
  };

  const handleKeyDown = (e: React.KeyboardEvent) => {
    if (e.key === "Enter" && !e.shiftKey) {
      e.preventDefault();
      handleSubmit(e as any);
    }
  };

  const wordCount = getWordCount(message);
  const isDisabled = !message.trim() || wordCount > 1500 || sendMessage.isPending;

  return (
    <footer className="bg-card border-t border-border p-4" data-testid="message-input-container">
      <form className="flex items-end space-x-3" onSubmit={handleSubmit}>
        <div className="flex-1">
          <div className="relative">
            <textarea 
              className="chat-input w-full bg-input border border-border rounded-lg px-4 py-3 text-foreground placeholder-muted-foreground resize-none focus:outline-none focus:ring-2 focus:ring-ring transition-all"
              placeholder="Type your message..."
              rows={1}
              value={message}
              onChange={(e) => setMessage(e.target.value)}
              onKeyDown={handleKeyDown}
              data-testid="input-message"
              style={{
                minHeight: '48px',
                maxHeight: '200px',
                height: 'auto',
              }}
            />
            <div className="absolute bottom-2 right-2 text-xs text-muted-foreground" data-testid="text-word-count">
              {wordCount}/1500 words
            </div>
          </div>
        </div>
        <button 
          type="submit"
          disabled={isDisabled}
          className="bg-primary hover:bg-primary/90 text-primary-foreground px-4 py-3 rounded-lg font-medium transition-colors flex items-center space-x-2 disabled:opacity-50 disabled:cursor-not-allowed"
          data-testid="button-send">
          <Send size={16} />
          <span className="hidden sm:inline">Send</span>
        </button>
      </form>
      
      <div className="flex items-center justify-between mt-3 text-xs text-muted-foreground">
        <div className="flex items-center space-x-2">
          <div className="w-2 h-2 bg-green-500 rounded-full"></div>
          <span data-testid="text-status">Connected</span>
        </div>
        <div data-testid="text-last-message">
          Last message: just now
        </div>
      </div>
    </footer>
  );
}
