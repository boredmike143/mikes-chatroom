import { MessageSquare, Settings } from "lucide-react";

interface ChatHeaderProps {
  onlineCount: number;
  currentUser: string;
  onOpenSettings: () => void;
}

export function ChatHeader({ onlineCount, currentUser, onOpenSettings }: ChatHeaderProps) {
  const getUserInitials = (username: string) => {
    return username.slice(0, 2).toUpperCase();
  };

  return (
    <header className="bg-card border-b border-border px-4 py-3 flex items-center justify-between" data-testid="chat-header">
      <div className="flex items-center space-x-3">
        <div className="w-8 h-8 bg-primary rounded-lg flex items-center justify-center">
          <MessageSquare className="text-primary-foreground text-sm" size={16} />
        </div>
        <div>
          <h1 className="text-lg font-semibold text-foreground" data-testid="chat-title">Global Chatroom</h1>
          <p className="text-sm text-muted-foreground" data-testid="online-count">
            {onlineCount} users online
          </p>
        </div>
      </div>
      
      <div className="flex items-center space-x-3">
        <div className="status-indicator">
          <div className="w-8 h-8 bg-accent rounded-full flex items-center justify-center" data-testid="user-avatar">
            <span className="text-sm font-medium text-accent-foreground">
              {getUserInitials(currentUser)}
            </span>
          </div>
        </div>
        <button 
          className="text-muted-foreground hover:text-foreground transition-colors p-2 rounded-md hover:bg-accent"
          onClick={onOpenSettings}
          data-testid="button-settings">
          <Settings size={16} />
        </button>
      </div>
    </header>
  );
}
