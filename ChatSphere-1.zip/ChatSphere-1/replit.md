# Overview

This is a real-time chat application built with React, Express, and PostgreSQL. The application provides a simple chatroom interface where users can send messages, view chat history, and customize their usernames. It features a modern UI built with Tailwind CSS and shadcn/ui components, session-based user management, and real-time message updates through polling.

# User Preferences

Preferred communication style: Simple, everyday language.

# System Architecture

## Frontend Architecture
The frontend is built with React and TypeScript, utilizing a component-based architecture:
- **Routing**: Uses wouter for lightweight client-side routing
- **State Management**: TanStack Query for server state management with caching and automatic refetching
- **UI Framework**: shadcn/ui components built on Radix UI primitives with Tailwind CSS for styling
- **Build Tool**: Vite for fast development and optimized production builds
- **Component Structure**: Modular components including ChatHeader, MessageFeed, MessageInput, and UsernameModal

## Backend Architecture
The backend follows a RESTful API design pattern:
- **Framework**: Express.js with TypeScript for type safety
- **Session Management**: Express sessions for user identification without traditional authentication
- **Data Validation**: Zod schemas for request/response validation
- **Storage Layer**: Abstracted storage interface allowing for both in-memory and database implementations
- **API Structure**: Clean separation of routes, storage logic, and middleware

## Data Storage
The application uses a hybrid storage approach:
- **Database**: PostgreSQL with Drizzle ORM for schema management and type-safe queries
- **Session Storage**: In-memory session management for temporary user identification
- **Migration Support**: Drizzle Kit for database schema migrations
- **Fallback Storage**: In-memory storage implementation for development/testing

## Authentication and Authorization
Simplified session-based user management:
- **No Traditional Auth**: Users are identified by session IDs without passwords or registration
- **Auto-Generated Usernames**: Random usernames assigned to new sessions
- **Username Customization**: Users can update their display names through the UI
- **Session Persistence**: Sessions maintained across browser sessions for continuity

# External Dependencies

## Database
- **Neon Database**: Serverless PostgreSQL database hosting
- **Drizzle ORM**: Type-safe database toolkit for schema definition and queries
- **connect-pg-simple**: PostgreSQL session store for Express sessions

## UI Components
- **Radix UI**: Headless UI primitives for accessible component foundation
- **Tailwind CSS**: Utility-first CSS framework for styling
- **Lucide React**: Icon library for consistent iconography
- **shadcn/ui**: Pre-built component library combining Radix UI and Tailwind CSS

## Development Tools
- **Vite**: Build tool and development server
- **TypeScript**: Type safety across frontend and backend
- **ESBuild**: Fast JavaScript bundler for production builds
- **TanStack Query**: Data fetching and caching library for React

## Deployment
- **Replit**: Hosting platform with integrated development environment
- **Cartographer**: Replit-specific development tooling for enhanced debugging